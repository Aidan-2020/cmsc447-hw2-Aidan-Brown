from flask import Flask, render_template, url_for, request, redirect
import sqlite3

app = Flask(__name__)

@app.route('/')
def display_data():
    # Connect to the SQLite database
    conn = sqlite3.connect('test.db')
    
    # Create a cursor object
    cursor = conn.cursor()
    
    # Execute a query to retrieve data from the database
    cursor.execute('SELECT * FROM users')
    
    # Fetch all the data
    data = cursor.fetchall()
    
    # Close the connection
    conn.close()
    
    # Render the template with the data
    return render_template('display_data.html', data=data)

# Add a new route for handling the form submission
@app.route('/add_item', methods=['POST'])
def add_item():
    if request.method == 'POST':
        # Get data from the form
        name = request.form['name']
        id = request.form['id']
        points = request.form['points']

        # Connect to the SQLite database
        conn = sqlite3.connect('test.db')
        cursor = conn.cursor()

        # Insert new data into the database
        cursor.execute('INSERT INTO users (name, id, points) VALUES (?, ?, ?)', (name, id, points))

        # Commit changes and close the connection
        conn.commit()
        conn.close()

        # Redirect to the main page after adding the new item
        return redirect(url_for('display_data'))
    else:
        # Handle invalid request method
        return redirect(url_for('display_data'))
    
# Add a new route for handling the search request
@app.route('/search_item', methods=['POST'])
def search_item():
    if request.method == 'POST':
        # Get the ID from the form
        search_id = request.form['searchId']

        # Connect to the SQLite database
        conn = sqlite3.connect('test.db')
        cursor = conn.cursor()

        # Execute a query to retrieve data for the given ID
        cursor.execute('SELECT * FROM users WHERE id = ?', (search_id,))
            
        # Fetch the data
        result = cursor.fetchone()

        # Close the connection
        conn.close()

        # Display the result in the result popup
        return render_template('search_result.html', result=result)
    else:
        # Handle invalid request method
        return redirect(url_for('display_data'))
    
# Add a new route for handling the delete request
@app.route('/delete_item', methods=['POST'])
def delete_item():
    if request.method == 'POST':
        try:
            # Get the ID from the form
            delete_id = request.form['deleteId']

            # Connect to the SQLite database
            conn = sqlite3.connect('test.db')
            cursor = conn.cursor()

            # Execute a query to delete the item with the given ID
            cursor.execute('DELETE FROM users WHERE id = ?', (delete_id,))

            # Commit changes and close the connection
            conn.commit()
            conn.close()

            return "Item deleted successfully"

        except Exception as e:
            # Log the error for debugging
            print(f"Error during delete: {str(e)}")
            return "Error deleting item"

    else:
        # Handle invalid request method
        return redirect(url_for('display_data'))
    
# Add a new route for handling the update request
@app.route('/update_item', methods=['POST'])
def update_item():
    if request.method == 'POST':
        try:
            # Get the update data from the form
            update_id = request.form['updateId']
            update_name = request.form['updateName']
            update_points = request.form['updatePoints']

            # Connect to the SQLite database
            conn = sqlite3.connect('test.db')
            cursor = conn.cursor()

            # Execute a query to update the item with the given ID
            cursor.execute('UPDATE users SET name = ?, points = ? WHERE id = ?', (update_name, update_points, update_id))

            # Commit changes and close the connection
            conn.commit()
            conn.close()

            return "Item updated successfully"

        except Exception as e:
            # Log the error for debugging
            print(f"Error during update: {str(e)}")
            return "Error updating item"

    else:
        # Handle invalid request method
        return redirect(url_for('display_data'))

if __name__ == "__main__":
    app.run(debug=True)